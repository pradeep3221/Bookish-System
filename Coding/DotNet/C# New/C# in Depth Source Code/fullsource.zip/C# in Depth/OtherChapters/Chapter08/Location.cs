﻿using System.ComponentModel;

namespace Chapter08
{
    [Description("Listing 8.2")]
    public class Location
    {
        public string Country { get; set; }
        public string Town { get; set; }
    }
}
