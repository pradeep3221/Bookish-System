using System.ComponentModel;

namespace Chapter07
{
    [Description("Listing 7.09")]
    class UnusedFieldWithWarning
    {
        int x;
    }
}
