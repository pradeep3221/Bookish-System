﻿print "hello, world"
