﻿using MiscUtil;

namespace Chapter16
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationChooser.Run(typeof(Program), args);
        }
    }
}
