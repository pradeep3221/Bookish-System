﻿namespace Chapter11.Model
{
    public enum UserType : byte
    {
        Customer,
        Developer,
        Tester,
        Manager,
    }
}
