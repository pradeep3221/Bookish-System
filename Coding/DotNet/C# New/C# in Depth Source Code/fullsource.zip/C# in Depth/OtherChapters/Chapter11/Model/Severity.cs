﻿namespace Chapter11.Model
{
    public enum Severity : byte
    {
        Trivial,
        Minor,
        Major,
        Showstopper,
    }
}
