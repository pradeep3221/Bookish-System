﻿
namespace Chapter11.LogFile
{
    enum EntryType
    {
        Debug,
        Performance,
        Trace,
        Warning,
        Error,
    }
}
