﻿using MiscUtil;

namespace ReactiveExtensions
{
    class Program
    {
        static void Main(string[] args)
        {
            ApplicationChooser.Run(typeof(Program), args);
        }
    }
}
