﻿using System;
using System.ComponentModel;

namespace XmlExamples
{
    class CreateXml
    {
        static void Main()
        {
            Console.WriteLine (XmlSampleData.GetElement());
        }
    }
}
