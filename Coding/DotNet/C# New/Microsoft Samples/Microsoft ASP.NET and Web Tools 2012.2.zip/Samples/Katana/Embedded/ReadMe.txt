Embedded Sample
----------------------

Some OWIN servers can be run inside of your own process ("self-hosted").  This sample
shows how to start an OWIN application using the tools provided by the
Microsoft.Owin.Hosting nuget package.

This sample is provided as part of the ASP.NET Web Stack sample repository at
http://aspnet.codeplex.com/

For more information about the samples, please see
http://go.microsoft.com/fwlink/?LinkId=261487
