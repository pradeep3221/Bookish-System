﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using LeaveSample.Entities;

namespace LeaveSample.UI.Web.SignalR
{
    public class LeaveActionHub : Hub
    {
    }
}