﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace _3_tier_Sample
{
    public class DAL
    {
        //SQL Connection string 
        string ConnectionString = ConfigurationManager.AppSettings["LocalConnection"].ToString();

        #region Insert User Details
        /// <summary>
        /// Insert Job Details
        /// </summary>
        /// <param name="objBELJobs"></param>
        /// <returns></returns>
        public string InsertUserInformation(BEL objBELUserDetails)
        {
            SqlConnection con = new SqlConnection(ConnectionString);
           con.Open();
            SqlCommand cmd = new SqlCommand("sp_userinformation", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
            cmd.Parameters.AddWithValue("@UserName",objBELUserDetails.UserName);
            cmd.Parameters.AddWithValue("@Password", objBELUserDetails.Password);
            cmd.Parameters.AddWithValue("@FirstName", objBELUserDetails.FirstName);
            cmd.Parameters.AddWithValue("@LastName", objBELUserDetails.LastName);
            cmd.Parameters.AddWithValue("@Email", objBELUserDetails.Email);
            cmd.Parameters.AddWithValue("@PhoneNo", objBELUserDetails.Phoneno);
            cmd.Parameters.AddWithValue("@Location", objBELUserDetails.Location);
            cmd.Parameters.AddWithValue("@Created_By", objBELUserDetails.Created_By);
            cmd.Parameters.Add("@ERROR", SqlDbType.Char, 500);
            cmd.Parameters["@ERROR"].Direction = ParameterDirection.Output;
            cmd.ExecuteNonQuery();
            string strMessage = (string) cmd.Parameters["@ERROR"].Value;
            con.Close();
                return strMessage;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
                con.Dispose();
            }
        }
        #endregion
    }
}
