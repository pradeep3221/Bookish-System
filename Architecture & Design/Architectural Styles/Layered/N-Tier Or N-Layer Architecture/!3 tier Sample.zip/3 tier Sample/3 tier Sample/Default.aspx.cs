﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace _3_tier_Sample
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            btnsubmit.Attributes.Add("onclick", "javascript:return validate()");
        }
        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            string Output = string.Empty;
            if (txtpwd.Text == txtcnmpwd.Text)
            {
                   BEL objUserBEL = new BEL();

                   objUserBEL.UserName = txtuser.Text;
                   objUserBEL.Password = txtpwd.Text;
                   objUserBEL.FirstName = txtfname.Text;
                   objUserBEL.LastName = txtlname.Text;
                   objUserBEL.Email = txtEmail.Text;
                   objUserBEL.Phoneno = txtphone.Text;
                   objUserBEL.Location = txtlocation.Text;
                   objUserBEL.Created_By = txtuser.Text;
                   BLL objUserBLL = new BLL();
                   Output = objUserBLL.InsertUserDetails(objUserBEL);

            }
            else
            {
                Page.RegisterStartupScript("UserMsg", "<Script language='javascript'>alert('" + "Password mismatch" + "');</script>");
            }
           // Page.RegisterStartupScript("UserMsg", "<Script language='javascript'>window.alert('" + Output + "');</script>");
            lblErrorMsg.Text = Output;
          }

    }
}
