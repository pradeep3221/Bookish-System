﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _3_tier_Sample
{
    public class BEL
    {
        #region Variables
        /// <summary>
        /// User Registration Variables
        /// </summary>
        private string _UserName;
        private string _Password;
        private string _FirstName;
        private string _LastName;
        private string _Email;
        private string _Phoneno;
        private string _Location;
        private string _Created_By;
       #endregion

        /// <summary>
        /// Gets or sets the <b>_UserName</b> attribute value.
        /// </summary>
        /// <value>The <b>_UserName</b> attribute value.</value>
        public string UserName
        {
            get
            {
                return _UserName;
            }
            set
            {
                _UserName = value;
            }
        }

        /// <summary>
        /// Gets or sets the <b>_Password</b> attribute value.
        /// </summary>
        /// <value>The <b>_Password</b> attribute value.</value>
        public string Password
        {
            get
            {
                return _Password;
            }
            set
            {
                _Password = value;
            }
        }

        /// <summary>
        /// Gets or sets the <b>_FirstName</b> attribute value.
        /// </summary>
        /// <value>The <b>_FirstName</b> attribute value.</value>
        public string FirstName
        {
            get
            {
                return _FirstName;
            }
            set
            {
                _FirstName = value;
            }
        }
        /// <summary>
        /// Gets or sets the <b>_LastName</b> attribute value.
        /// </summary>
        /// <value>The <b>_LastName</b> attribute value.</value>
        public string LastName
        {
            get
            {
                return _LastName;
            }
            set
            {
                _LastName = value;
            }
        }

        /// <summary>
        /// Gets or sets the <b>_Email</b> attribute value.
        /// </summary>
        /// <value>The <b>_Email</b> attribute value.</value>
        public string Email
        {
            get
            {
                return _Email;
            }
            set
            {
                _Email = value;
            }
        }

        /// <summary>
        /// Gets or sets the <b>_Phoneno</b> attribute value.
        /// </summary>
        /// <value>The <b>_Phoneno</b> attribute value.</value>
        public string Phoneno
        {
            get
            {
                return _Phoneno;
            }
            set
            {
                _Phoneno = value;
            }
        }

        /// <summary>
        /// Gets or sets the <b>_Location</b> attribute value.
        /// </summary>
        /// <value>The <b>_Location</b> attribute value.</value>
        public string Location
        {
            get
            {
                return _Location;
            }
            set
            {
                _Location = value;
            }
        }

        /// <summary>
        /// Gets or sets the <b>_Created_By</b> attribute value.
        /// </summary>
        /// <value>The <b>_Created_By</b> attribute value.</value>
        public string Created_By
        {
            get
            {
                return _Created_By;
            }
            set
            {
                _Created_By = value;
            }
        }
     }
}
