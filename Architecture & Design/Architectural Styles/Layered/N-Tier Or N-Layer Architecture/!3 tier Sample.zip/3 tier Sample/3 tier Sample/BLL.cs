﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _3_tier_Sample
{
    public class BLL
    {
        #region Insert UserInformationDetails
        /// <summary>
        /// Insert UserDetails
        /// </summary>
        /// <param name="objUserBEL"></param>
        /// <returns></returns>
        public string InsertUserDetails(BEL objUserDetails)
        {
            DAL objUserDAL = new DAL();
            try
            {
                return objUserDAL.InsertUserInformation(objUserDetails);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                objUserDAL = null;
            }
        }
        #endregion
    }
}
