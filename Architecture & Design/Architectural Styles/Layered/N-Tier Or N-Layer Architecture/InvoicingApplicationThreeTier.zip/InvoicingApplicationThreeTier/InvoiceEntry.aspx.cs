﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Invoicing;
public partial class InvoiceEntry : System.Web.UI.Page
{
    private clsProduct objProductSelected;
    protected void Page_Load(object sender, EventArgs e)
    {
        LoadGrid();
        if (Session["InvoiceSession"] == null)
        {
            Session["InvoiceSession"] = new clsInvoice();
        }
        Uri objUri = Request.UrlReferrer;
        if (objUri != null)
        {
            if (objUri.AbsolutePath.Contains("SelectProducts.aspx"))
            {
                LoadProduct();
                GetInvoiceFromSession();
            }
        }
    }
    private void LoadProduct()
    {
      objProductSelected = (clsProduct)Session["SelectedProduct"];
      
      if (objProductSelected != null)
      {
          ((clsInvoice)Session["InvoiceSession"]).ProductId = objProductSelected.ProductId;
          ((clsInvoice)Session["InvoiceSession"]).ProductDescription = objProductSelected.ProductDescription;
          ((clsInvoice)Session["InvoiceSession"]).UnitCost = objProductSelected.UnitCost;

      }
    }
    private void LoadGrid()
    {
        // load the data set in to the data grid
        clsInvoice objInvoice = new clsInvoice();
        dtgInvoice.DataSource = objInvoice.getInvoice();
        dtgInvoice.DataBind();
    }
    public void clearText()
    {
        txtInvoiceNumber.Text = "";
        txtComments.Text = "";
        txtInvoiceDate.Text = "";
        TxtQuantity.Text = "";
        lblTotalAmountToBePaid.Text = "";
        txtTaxAmount.Text = "";
        txtAmountPaid.Text = "";
        txtCustomerName.Text = "";
        txtCustomerAddress.Text = "";
        lblProductUnitCost.Text = "";
        lblProductDescription.Text = "";
    }
    protected void btnAddInvoice_Click(object sender, EventArgs e)
    {
        try
        {
            clsInvoice objInvoice = new clsInvoice();
            objInvoice = (clsInvoice)Session["InvoiceSession"];
            setObjectFromUI(objInvoice);
            objInvoice.Insert();
            LoadGrid();
            clearText();
            clearSession();
        }
        catch (Exception ex)
        {
            lblErrorMessage.Text = ex.Message.ToString();
        }
    }
    private void GetInvoiceFromSession()
    {
        clsInvoice objInvoice = new clsInvoice();
        objInvoice = (clsInvoice) Session["InvoiceSession"];
        setUIfromObject(objInvoice);
        
    }
    
    public void setObjectFromUI(clsInvoice objInvoice)
    {
        try
        {
            
            objInvoice.CustomerName = txtCustomerName.Text;
            objInvoice.CustomerAddress = txtCustomerAddress.Text;
            if (lblTotalAmountToBePaid.Text.Length != 0)
            {
                objInvoice.Amount = Convert.ToDouble(lblTotalAmountToBePaid.Text);
            }
            if (txtAmountPaid.Text.Length != 0)
            {
                objInvoice.PaidAmount = Convert.ToDouble(txtAmountPaid.Text);
            }
            if (txtInvoiceDate.Text.Length != 0)
            {
                objInvoice.InvoiceDate = Convert.ToDateTime(txtInvoiceDate.Text);
            }
            objInvoice.InvoiceComments = txtComments.Text;
            if (TxtQuantity.Text.Length != 0)
            {
                objInvoice.Quantity = Convert.ToInt16(TxtQuantity.Text);
            }
            if (txtTaxAmount.Text.Length != 0)
            {
                objInvoice.TaxAmount = Convert.ToDouble(txtTaxAmount.Text);
            }
            
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void setUIfromObject(clsInvoice objInvoice)
    {
        
        txtCustomerName.Text = objInvoice.CustomerName;
        txtInvoiceNumber.Text = objInvoice.InvoiceReference.ToString();
        txtCustomerAddress.Text = objInvoice.CustomerAddress;
        lblTotalAmountToBePaid.Text = objInvoice.Amount.ToString();
        txtAmountPaid.Text = objInvoice.PaidAmount.ToString();
        txtInvoiceDate.Text = objInvoice.InvoiceDate.ToString();
        txtComments.Text = objInvoice.InvoiceComments;
        
        txtInvoiceNumber.Text = objInvoice.InvoiceReference.ToString();
        TxtQuantity.Text = objInvoice.Quantity.ToString();
        txtTaxAmount.Text = objInvoice.TaxAmount.ToString();
        lblProductUnitCost.Text = objInvoice.UnitCost.ToString();
        lblProductDescription.Text = objInvoice.ProductDescription.ToString();
        lblTotalAmountToBePaid.Text = objInvoice.Amount.ToString();
    }
    private void clearSession()
    {
        Session["InvoiceSession"] = null;
        Session["SelectedProduct"] = null;
    }
    protected void btnUpdateInvoice_Click(object sender, EventArgs e)
    {

        clsInvoice objInvoice = new clsInvoice();
        objInvoice = (clsInvoice)Session["InvoiceSession"];
        try
        {
            setObjectFromUI(objInvoice);
            objInvoice.Update();
            clearText();
            LoadGrid();
            clearSession();
        }
        catch (Exception ex)
        {
            lblErrorMessage.Text = ex.Message.ToString();
        }
    }
    protected void btnDeleteInvoice_Click(object sender, EventArgs e)
    {
        clsInvoice objInvoice = new clsInvoice();
        objInvoice = (clsInvoice)Session["InvoiceSession"];
        setObjectFromUI(objInvoice);
        objInvoice.Delete();
        clearText();
        LoadGrid();
        clearSession();
    }
    protected void dtgInvoice_SelectedIndexChanged(object sender, EventArgs e)
    {
        clsInvoice objInvoice = new clsInvoice();
        objInvoice.LoadInvoice(Convert.ToInt16(dtgInvoice.SelectedItem.Cells[1].Text.ToString()));
        setUIfromObject(objInvoice);
        Session["InvoiceSession"] = objInvoice;
    }
    protected void btnProducts_Click(object sender, EventArgs e)
    {

    }
    protected void btnProductsSelect_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("SelectProducts.aspx");
        }
        catch (Exception ex)
        {
            lblErrorMessage.Text = ex.Message.ToString();
        }
    }
    protected void TxtQuantity_TextChanged(object sender, EventArgs e)
    {

            clsInvoice objInvoice = new clsInvoice();
            objInvoice = (clsInvoice)Session["InvoiceSession"];
            objInvoice.Quantity = Convert.ToInt16(TxtQuantity.Text);
            setUIfromObject(objInvoice);
       
    }
   
}
