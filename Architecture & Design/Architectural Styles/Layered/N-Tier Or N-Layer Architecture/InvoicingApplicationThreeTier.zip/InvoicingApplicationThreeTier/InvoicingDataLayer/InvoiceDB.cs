﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace InvoicingDataLayer
{
    public class clsInvoiceDB
    {
        public void InsertInvoice(string _InvoiceComments, DateTime _InvoiceDate, int _productId,  int _Qty, double _Amount, double _TaxAmount, double _PaidAmount, string _CustomerName, string _CustomerAddress, double _UnitCost)   
        {
            SqlConnection ObjConnection = new SqlConnection();
            ObjConnection.ConnectionString = ConfigurationSettings.AppSettings["ConnectionString"];
            ObjConnection.Open();
            SqlCommand objCommand = new SqlCommand();
            objCommand.Connection = ObjConnection;
            objCommand.CommandText = "usp_InsertInvoice";
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Add(new SqlParameter("@InvoiceComments", _InvoiceComments));
            objCommand.Parameters.Add(new SqlParameter("@InvoiceDate", _InvoiceDate));
            objCommand.Parameters.Add(new SqlParameter("@ProductId", _productId));
            objCommand.Parameters.Add(new SqlParameter("@Qty", _Qty));
            objCommand.Parameters.Add(new SqlParameter("@Amount", _Amount));
            objCommand.Parameters.Add(new SqlParameter("@TaxAmount", _TaxAmount));
            objCommand.Parameters.Add(new SqlParameter("@PaidAmount", _PaidAmount));
            objCommand.Parameters.Add(new SqlParameter("@CustomerName", _CustomerName));
            objCommand.Parameters.Add(new SqlParameter("@CustomerAddress", _CustomerAddress));
            objCommand.Parameters.Add(new SqlParameter("@UnitCost", _UnitCost));

            objCommand.ExecuteNonQuery();
            ObjConnection.Close();
        }
        public void UpdateInvoice(int _InvoiceReference, string _InvoiceComments, DateTime _InvoiceDate, int _productId, int _Qty, double _Amount, double _TaxAmount, double _PaidAmount, string _CustomerName, string _CustomerAddress, double _UnitCost)
        {
            SqlConnection ObjConnection = new SqlConnection();
            ObjConnection.ConnectionString = ConfigurationSettings.AppSettings["ConnectionString"];
            ObjConnection.Open();
            SqlCommand objCommand = new SqlCommand();
            objCommand.Connection = ObjConnection;
            objCommand.CommandText = "usp_UpdateInvoice";
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Add(new SqlParameter("InvoiceReference", _InvoiceReference));
            objCommand.Parameters.Add(new SqlParameter("@InvoiceComments", _InvoiceComments));
            objCommand.Parameters.Add(new SqlParameter("@InvoiceDate", _InvoiceDate));
            objCommand.Parameters.Add(new SqlParameter("@ProductId", _productId));
            objCommand.Parameters.Add(new SqlParameter("@Qty", _Qty));
            objCommand.Parameters.Add(new SqlParameter("@Amount", _Amount));
            objCommand.Parameters.Add(new SqlParameter("@TaxAmount", _TaxAmount));
            objCommand.Parameters.Add(new SqlParameter("@PaidAmount", _PaidAmount));
            objCommand.Parameters.Add(new SqlParameter("@CustomerName", _CustomerName));
            objCommand.Parameters.Add(new SqlParameter("@CustomerAddress", _CustomerAddress));
            objCommand.Parameters.Add(new SqlParameter("@UnitCost", _UnitCost));

            objCommand.ExecuteNonQuery();
            ObjConnection.Close();
        }
        public void DeleteInvoice(int _InvoiceReference)
        {
            SqlConnection ObjConnection = new SqlConnection();
            ObjConnection.ConnectionString = ConfigurationSettings.AppSettings["ConnectionString"];
            ObjConnection.Open();
            SqlCommand objCommand = new SqlCommand();
            objCommand.Connection = ObjConnection;
            objCommand.CommandText = "usp_DeleteInvoice";
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Add(new SqlParameter("InvoiceReference", _InvoiceReference));
            objCommand.ExecuteNonQuery();
            ObjConnection.Close();
        }
        public DataSet getInvoice()
        { 
            DataSet objdataset = new DataSet();
            SqlConnection ObjConnection = new SqlConnection();
            ObjConnection.ConnectionString = ConfigurationSettings.AppSettings["ConnectionString"];
            ObjConnection.Open();
            SqlCommand objCommand = new SqlCommand();
            objCommand.Connection = ObjConnection;
            objCommand.CommandText = "usp_getInvoice";
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Add(new SqlParameter("InvoiceReference", ""));
            SqlDataAdapter objDataAdapter = new SqlDataAdapter(objCommand);
            objDataAdapter.Fill(objdataset);
            ObjConnection.Close();
            return objdataset;
        }
        public DataSet getInvoice(int _InvoiceReference)
        {
            DataSet objdataset = new DataSet();
            SqlConnection ObjConnection = new SqlConnection();
            ObjConnection.ConnectionString = ConfigurationSettings.AppSettings["ConnectionString"];
            ObjConnection.Open();
            SqlCommand objCommand = new SqlCommand();
            objCommand.Connection = ObjConnection;
            objCommand.CommandText = "usp_getInvoice";
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.Parameters.Add(new SqlParameter("InvoiceReference", _InvoiceReference));
            SqlDataAdapter objDataAdapter = new SqlDataAdapter(objCommand);
            objDataAdapter.Fill(objdataset);
            ObjConnection.Close();
            return objdataset;
        }
        public DataSet getProducts()
        {
            DataSet objdataset = new DataSet();
            SqlConnection ObjConnection = new SqlConnection();
            ObjConnection.ConnectionString = ConfigurationSettings.AppSettings["ConnectionString"];
            ObjConnection.Open();
            SqlCommand objCommand = new SqlCommand();
            objCommand.Connection = ObjConnection;
            objCommand.CommandText = "usp_getProducts";
            objCommand.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter objDataAdapter = new SqlDataAdapter(objCommand);
            objDataAdapter.Fill(objdataset);
            ObjConnection.Close();
            return objdataset;
        }

    }
}
