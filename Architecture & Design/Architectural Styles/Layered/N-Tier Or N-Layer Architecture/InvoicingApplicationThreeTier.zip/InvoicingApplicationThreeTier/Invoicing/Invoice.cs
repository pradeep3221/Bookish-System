﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using InvoicingDataLayer;
namespace Invoicing
{
    public class clsInvoice
    {
        private int _InvoiceReference;
        private string _InvoiceComments="";
        private DateTime _InvoiceDate;
        private int _ProductId;
        private int _Qty;
        private double _Amount;
        private double _PaidAmount;
        private double _TaxAmount;
        private string _CustomerName="";
        private string _CustomerAddress="";
        private double _UnitCost;
        private string _Description="";

        public string ProductDescription
        {
            set
            {
                _Description = value;
            }
            get
            {
                return _Description;
            }
        }
        public int InvoiceReference
        {
            get
            {
                return _InvoiceReference;
            }
        }
        public string InvoiceComments
        {
            set
            {
                
                _InvoiceComments = value;
            }
            get
            {
                return _InvoiceComments;
            }
        }
        public DateTime InvoiceDate
        {
            set
            {
                _InvoiceDate = value;
            }
            get
            {
                return _InvoiceDate;
            }
        }
        public int ProductId
        {
            set
            {
                if (value == 0)
                {
                    throw new Exception("Product  is compulsory");
                  
                }
                _ProductId = value;
            }
            get
            {
                return _ProductId;
            }
        }
        public int Quantity
        {
            set
            {
                if (value < 1)
                {
                   throw new Exception("Quantity should be numeric");
                }
                _Qty = value;
                _Amount = _UnitCost * _Qty;
            }
            get
            {
                return _Qty;
            }
        }
        public double Amount
        {
            set
            {
                _Amount = value;
            }
            get
            {
                return _Amount;
            }
        }
        public double PaidAmount
        {
            set
            {
                _PaidAmount = value;
            }
            get
            {
                return _PaidAmount;
            }
        }
        public double TaxAmount
        {
            set
            {
                _TaxAmount = value;
            }
            get
            {
                return _TaxAmount;
            }
        }
        public string CustomerName
        {
            set
            {
                if (value.Length == 0)
                {
                    throw new Exception("Customer Name is compulsory");
                }
                _CustomerName = value; 
            }
            get
            {
                return _CustomerName;
            }
        }
        public string CustomerAddress
        {
            set
            {
                _CustomerAddress = value;
            }
            get
            {
                return _CustomerAddress;
            }
        }
        public double UnitCost
        {
            set
            {
                if (value == 0)
                {
                    throw new Exception("Unit cost is compulsory");
                }
                _UnitCost = value;
                _Amount = _UnitCost * _Qty;
            }
            get
            {
                return _UnitCost;
            }
        }
        public void Insert()
        {
            clsInvoiceDB objInvoiceDB = new clsInvoiceDB();
           
            objInvoiceDB.InsertInvoice(_InvoiceComments, _InvoiceDate, _ProductId, _Qty, _Amount, _TaxAmount, _PaidAmount, _CustomerName,_CustomerAddress, _UnitCost);
        }
        public void Update()
        {
            clsInvoiceDB objInvoiceDB = new clsInvoiceDB();
            objInvoiceDB.UpdateInvoice(_InvoiceReference, _InvoiceComments, _InvoiceDate, _ProductId, _Qty, _Amount, _TaxAmount, _PaidAmount, _CustomerName, _CustomerAddress, _UnitCost);
        }
        public void Delete()
        {
            clsInvoiceDB objInvoiceDB = new clsInvoiceDB();
            objInvoiceDB.DeleteInvoice(_InvoiceReference);
        }
        public DataSet getInvoice()
        {
            clsInvoiceDB objInvoiceDB = new clsInvoiceDB();
            return objInvoiceDB.getInvoice();
        }
        public void LoadInvoice(int InvoiceNumber)
        {
            DataSet objdataset=null;
            clsInvoiceDB objInvoiceDB = new clsInvoiceDB();
            objdataset = objInvoiceDB.getInvoice(InvoiceNumber);
            _CustomerName = objdataset.Tables[0].Rows[0]["Customername"].ToString();
            _CustomerAddress = objdataset.Tables[0].Rows[0]["CustomerAddress"].ToString();
            _Amount = Convert.ToInt16(objdataset.Tables[0].Rows[0]["Amount"]);
            _PaidAmount = Convert.ToDouble(objdataset.Tables[0].Rows[0]["PaidAmount"]);
            _InvoiceDate = Convert.ToDateTime(objdataset.Tables[0].Rows[0]["InvoiceDate"]);
            _InvoiceComments = objdataset.Tables[0].Rows[0]["InvoiceComments"].ToString();
            _InvoiceReference = Convert.ToInt16(objdataset.Tables[0].Rows[0]["InvoiceReference"]);
            _ProductId = Convert.ToInt16(objdataset.Tables[0].Rows[0]["ProductId_fk"]);
            _Description = objdataset.Tables[0].Rows[0]["ProductDescription"].ToString();
            _Qty = Convert.ToInt16(objdataset.Tables[0].Rows[0]["Qty"]);
            _TaxAmount = Convert.ToDouble(objdataset.Tables[0].Rows[0]["TaxAmount"]);
            _UnitCost = Convert.ToInt16(objdataset.Tables[0].Rows[0]["UnitCost"]);
        }
    }
    public class clsProduct
    {
        private int _ProductId;
        private string _productDescription;
        private double _UnitCost;
        public int ProductId
        {
            set
            {
                _ProductId = value;
            }
            get
            {
                return _ProductId;
            }
        }
        public string ProductDescription
        {
            set
            {
                _productDescription = value;
            }
            get
            {
                return _productDescription;
            }
        }
        public double UnitCost
        {
            set
            {
                _UnitCost = value;
            }
            get
            {
                return _UnitCost;
            }
        }
        public DataSet getProducts()
        {
            clsInvoiceDB objInvoiceDB = new clsInvoiceDB();
            return objInvoiceDB.getProducts();
        }
    }
}
