﻿namespace DesignPatterns.Interpreter
{
    public abstract class MelodyExpression
    {
        public abstract void Execute(Context context);
    }
}