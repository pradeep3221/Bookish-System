﻿namespace DesignPatterns.Interpreter
{
    public enum Octave
    {
        O0 = -4,
        O1 = -3,
        O2 = -2,
        O3 = -1,
        O4 = 0,
        O5 = 1,
        O6 = 2
    }
}