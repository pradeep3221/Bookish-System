﻿namespace DesignPatterns.Interpreter
{
    public enum Accidental
    {
        Sharp = +1,
        Flat = -1,
        Natural = 0
    }
}