﻿namespace DesignPatterns.Interpreter
{
    public enum Tone
    {
        C = -9,
        D = -7,
        E = -5,
        F = -4,
        G = -2,
        A = 0,
        B = 2
    }
}