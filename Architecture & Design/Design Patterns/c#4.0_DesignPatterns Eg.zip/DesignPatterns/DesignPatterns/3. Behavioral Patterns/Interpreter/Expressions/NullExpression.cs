﻿namespace DesignPatterns.Interpreter
{
    internal class NullExpression : MelodyExpression
    {
        public override void Execute(Context context)
        {
            
        }
    }
}