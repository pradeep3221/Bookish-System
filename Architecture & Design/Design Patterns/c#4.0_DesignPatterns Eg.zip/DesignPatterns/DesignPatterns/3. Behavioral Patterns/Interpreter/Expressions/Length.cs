﻿namespace DesignPatterns.Interpreter
{
    public enum Length
    {
        L1 = 1,
        L2 = 2,
        L4 = 4,
        L8 = 8,
        L16 = 16,
        L32 = 32,
        L64 = 64 
    }
}