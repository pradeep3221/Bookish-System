﻿namespace DesignPatterns.Interpreter
{
    public enum Duration
    {
        Legato,
        Normal,
        Stacatto,
        None
    }
}