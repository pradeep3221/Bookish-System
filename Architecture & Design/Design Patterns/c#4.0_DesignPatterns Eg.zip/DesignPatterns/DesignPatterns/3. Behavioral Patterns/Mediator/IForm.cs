﻿namespace DesignPatterns.Mediator
{
    public interface IForm
    {
        void Refresh();
    }
}