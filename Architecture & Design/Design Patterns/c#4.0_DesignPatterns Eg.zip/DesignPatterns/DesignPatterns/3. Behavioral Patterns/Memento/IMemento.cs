﻿namespace DesignPatterns.Memento
{
    public interface IMemento
    {
        string GetDescription();
    }
}