﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.VisitorPattern
{
    class CompanyPresident : Employee
    {
        // Constructor
        public CompanyPresident() : base("Dick", 45000.0, 21)
        {
        }        
    }
}
