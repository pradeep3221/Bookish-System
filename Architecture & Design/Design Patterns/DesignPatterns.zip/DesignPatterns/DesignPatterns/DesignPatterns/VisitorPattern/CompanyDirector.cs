﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.VisitorPattern
{
    class CompanyDirector : Employee
    {
        // Constructor
        public CompanyDirector() : base("Elly", 35000.0, 16)
        {
        }
    }
}
