﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.VisitorPattern
{
    class Clerk : Employee
    {
        // Constructor
        public Clerk() : base("Hank", 25000.0, 14)
        {
        }
    }
}
