﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.CommandPattern
{
    public abstract class CalcCommand
    {
        public abstract void Execute();
        public abstract void UnExecute();
    }
}
