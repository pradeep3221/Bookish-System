﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.BridgePattern
{
    public class SmartTV
    {
        public IVideoSource VideoSource { get; set; }
        
        public void ShowTvGuide()
        {
            if (VideoSource != null)
            {
                Console.WriteLine(VideoSource.GetTvGuide());
            }
            else
            {
                Console.WriteLine("Please select a Video Source to get TV guide from");
            }
        }

        public void PlayTV()
        {
            if (VideoSource != null)
            {
                Console.WriteLine(VideoSource.PlayVideo());
            }
            else
            {
                Console.WriteLine("Please select a Video Source to play");
            }
        }
    }

}
