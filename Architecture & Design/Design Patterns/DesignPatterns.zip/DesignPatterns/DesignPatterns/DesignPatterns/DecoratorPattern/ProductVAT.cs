﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.DecoratorPattern
{
    public class ProductVAT: ProductExpense
    {
        public ProductVAT(ProductBase b): base(b)
        {
            Console.WriteLine("ProductVAT constructor");
        }

        public override double Cost()
        {
            double cost = BaseObj.Cost();
            double d = (0.2 * cost) + cost;
            Console.WriteLine("Cost including VAT = " + d);
            return d;
        }
    }
}
