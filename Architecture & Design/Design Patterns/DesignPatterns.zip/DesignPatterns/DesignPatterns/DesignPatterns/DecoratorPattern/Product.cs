﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.DecoratorPattern
{
    public class Product: ProductBase
    {
        protected ProductBase BaseObj { get; set; }

        public override double Cost()
        {
            Console.WriteLine("TV cost = 500.00");
            return 500.00;
        } 
    }
}
