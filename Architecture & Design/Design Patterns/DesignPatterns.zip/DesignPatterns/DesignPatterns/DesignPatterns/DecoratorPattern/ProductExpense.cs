﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.DecoratorPattern
{
    public class ProductExpense: ProductBase
    {
        protected ProductBase BaseObj { get; set; }

        public ProductExpense(ProductBase b)
        {
            Console.WriteLine("ProductExpense constructor");
            BaseObj = b;
        }

        public override double Cost()
        {
            return BaseObj.Cost();
        } 
    }
}
