﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.DecoratorPattern
{
    public abstract class ProductBase
    {
        public abstract double Cost();
    }
}
