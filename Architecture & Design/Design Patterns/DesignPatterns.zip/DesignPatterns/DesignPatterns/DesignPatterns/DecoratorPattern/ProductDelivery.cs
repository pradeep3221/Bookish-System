﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.DecoratorPattern
{
    public class ProductDelivery: ProductExpense
    {
        public ProductDelivery(ProductBase b): base(b)
        {
            Console.WriteLine("ProductDelivery constructor");
        }

        public override double Cost()
        {
            double d = 25.00 + BaseObj.Cost();
            Console.WriteLine("With home delivery = " + d);
            return d;
        }
    }
}
