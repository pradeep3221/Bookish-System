﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DesignPatterns.FactoryPattern.Classes;

namespace DesignPatterns.FactoryPattern.Factories
{
    public class VehicleFactory
    {
        public IVehicle GetVehicle(String vehicle)
        {
            switch (vehicle)
            {
                case "Car":
                    return new Car();

                case "Bus":
                    return new Bus();

                case "Motorbike":
                    return new Motorbike();

                default:
                    throw new Exception("Invalid vehicle type");
            }
        }
    }
}
