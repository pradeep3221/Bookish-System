﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.FactoryPattern.Classes
{
    public class Motorbike: IVehicle
    {
        public void Drive(int miles)
        {
            Console.WriteLine(String.Format("Motorbike drove {0} miles", miles));
        }
    }
}
