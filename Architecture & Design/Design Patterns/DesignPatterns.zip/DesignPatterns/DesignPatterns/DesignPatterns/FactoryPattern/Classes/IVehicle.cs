﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.FactoryPattern.Classes
{
    public interface IVehicle
    {
        void Drive(int miles);
    }
}
