﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.FactoryPattern.Classes
{
    public class Car: IVehicle
    {
        public void Drive(int miles)
        {
            Console.WriteLine(String.Format("Car drove {0} miles", miles));
        }
    }
}
