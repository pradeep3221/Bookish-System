﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.PrototypePattern
{
    public class Developer : IEmployee
    {
        public String Name { get; set; }
        public String Department { get; set; }
        public String Language { get; set; }

        public IEmployee Clone()
        {
            return (IEmployee)MemberwiseClone();
        }

        public String GetDetails()
        {
            return String.Format("{0} - {1} - {2}", Name, Department, Language);  
        }
    }
}
