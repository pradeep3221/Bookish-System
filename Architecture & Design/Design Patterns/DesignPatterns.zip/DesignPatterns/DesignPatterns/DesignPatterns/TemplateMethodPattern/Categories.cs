﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace DesignPatterns.TemplateMethodPattern
{
    class Categories : DataAccessObject
    {
        public override void Select()
        {
            data = ProductCategoryRepository.ListAll();
        }
        
        public override void Process()
        {
            Console.WriteLine("Categories ---- ");

            DataTable dataTable = data.Tables[0];

            foreach (DataRow row in dataTable.Rows)
            {
                Console.WriteLine(row[0]);
            }
            Console.WriteLine();
        }
    }
}
