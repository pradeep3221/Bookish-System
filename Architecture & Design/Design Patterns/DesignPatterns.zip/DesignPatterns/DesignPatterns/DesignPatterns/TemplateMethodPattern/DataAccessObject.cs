﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Data;

namespace DesignPatterns.TemplateMethodPattern
{
    abstract class DataAccessObject
    {
        protected DataSet data {get; set;}
        
        public abstract void Select();
        public abstract void Process();

        // The 'Template Method' 
        public void Run()
        {                           
            Select();
            Process();           
        }
    }
}
