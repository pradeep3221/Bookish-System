﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace DesignPatterns.TemplateMethodPattern
{
    public static class ProductCategoryRepository
    {
        public static DataSet ListAll()
        {
            DataSet ds = new DataSet();
            ds.Tables.Add();
            ds.Tables[0].Columns.Add();
            ds.Tables[0].Rows.Add(new object[] { "Meat" });
            ds.Tables[0].Rows.Add(new object[] { "Fish" });
            ds.Tables[0].Rows.Add(new object[] { "Toys" });
            ds.Tables[0].Rows.Add(new object[] { "Clothes" });
            ds.Tables[0].Rows.Add(new object[] { "Shoes" });
            return ds;
        }
    }
}
