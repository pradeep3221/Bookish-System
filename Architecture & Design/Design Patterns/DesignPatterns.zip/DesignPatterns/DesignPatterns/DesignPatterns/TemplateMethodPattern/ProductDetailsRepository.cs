﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace DesignPatterns.TemplateMethodPattern
{
    public static class ProductDetailsRepository
    {
        public static DataSet ListAll()
        {
            DataSet ds = new DataSet();
            ds.Tables.Add();
            ds.Tables[0].Columns.Add();
            ds.Tables[0].Rows.Add(new object[] { "Steak" });
            ds.Tables[0].Rows.Add(new object[] { "Tuna" });
            ds.Tables[0].Rows.Add(new object[] { "Lego" });
            ds.Tables[0].Rows.Add(new object[] { "Sweater" });
            ds.Tables[0].Rows.Add(new object[] { "Sandals" });
            return ds;
        }
    }
}
