﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.SingletonPattern
{
    public sealed class Singleton
    {
        public String Title { get; set; }   
        
        private static readonly Singleton instance = new Singleton();

        private Singleton() { }

        public static Singleton Instance
        {
            get
            {
                instance.Title = "Current Instance"; 
                return instance;
            }
        }
    }

}
