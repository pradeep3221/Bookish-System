﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.FacadePattern
{
    public class BankCustomer
    {
        public String Name { get; set; }

        public BankCustomer(String name)
        {
            Name = name;
        }
    }
}
