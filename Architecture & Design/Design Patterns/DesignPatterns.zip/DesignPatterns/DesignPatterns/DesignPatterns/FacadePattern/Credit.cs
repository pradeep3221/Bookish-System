﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.FacadePattern
{
    public class Credit
    {
        public bool HasGoodCredit(BankCustomer c)
        {
            Console.WriteLine("Check credit for " + c.Name);
            return true;
        }
    }
}
