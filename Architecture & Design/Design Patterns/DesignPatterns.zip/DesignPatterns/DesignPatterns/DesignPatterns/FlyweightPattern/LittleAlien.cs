﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace DesignPatterns.FlyweightPattern
{
    public class LittleAlien : IAlien
    {
        private string shape = "Small Shape";  //intrinsic state

        public string Shape
        {
            get { return shape; }
        }

        public Enums.Color GetColor(int madLevel)   //extrinsic state
        {
            if (madLevel == 0)
                return Enums.Color.Green;
            else if (madLevel == 1)
                return Enums.Color.Red;
            else
                return Enums.Color.Blue;
        }
    }
}
