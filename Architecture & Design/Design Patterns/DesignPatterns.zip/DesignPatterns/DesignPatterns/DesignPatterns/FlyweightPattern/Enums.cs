﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.FlyweightPattern
{
    public static class Enums
    {
        public enum Color { Green, Red, Blue };
    }
}
