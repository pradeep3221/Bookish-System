﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.FlyweightPattern
{
    public interface IAlien
    { 
        string Shape { get; }  //intrinsic state

        Enums.Color GetColor(int madLevel);  //extrinsic state
    }
}
