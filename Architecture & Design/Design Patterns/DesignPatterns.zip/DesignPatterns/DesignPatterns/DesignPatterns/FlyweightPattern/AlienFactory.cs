﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.FlyweightPattern
{
    public class AlienFactory
    {
        private List<IAlien> list = new List<IAlien>();

        public void SaveAlien(IAlien alien)
        {
            list.Add(alien);
        }

        public IAlien GetAlien(int index)
        {
            return list[index];
        }
    }
}
