﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.ObserverPattern
{
    interface IInvestor
    {
        void Update(Stock stock);
    }
}
