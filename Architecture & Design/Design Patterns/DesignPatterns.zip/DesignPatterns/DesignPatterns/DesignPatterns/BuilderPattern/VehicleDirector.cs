﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.BuilderPattern
{
    public class VehicleDirector
    {
        public Vehicle BuildVehicle(IManufacturer manufacturer)
        {
            manufacturer.BuildBody();
            manufacturer.AddSeats();
            return manufacturer.GetVehicle();
        }
    }
}
