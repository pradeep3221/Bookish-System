﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.BuilderPattern
{
    public class FamilyCarManufacturer: IManufacturer
    {
        private Vehicle vehicle = new Vehicle();

        public void BuildBody()
        {
            vehicle.BodySpecification = "Saloon";
        }

        public void AddSeats()
        {
            vehicle.NumberOfSeats = 4;
        }

        public Vehicle GetVehicle()
        {
            return vehicle;
        }
    }
}
