﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.BuilderPattern
{
    public class Vehicle
    {
        public int NumberOfSeats { get; set; }
        public String BodySpecification { get; set; }

        public void Show()
        {
            Console.WriteLine("BodySpecification " + this.BodySpecification);
            Console.WriteLine("NumberOfSeats " + this.NumberOfSeats);
        }
    }
}
