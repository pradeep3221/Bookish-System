﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignPatterns.ChainOfResponsibilityPattern
{
    public class Purchase
    {
        public int Number { get; set; }
        public Double Amount { get; set; }
        public String Purpose { get; set; }

        public Purchase(int number, double amount, string purpose)
        {
            this.Number = number;
            this.Amount = amount;
            this.Purpose = purpose;
        }
    }
}
