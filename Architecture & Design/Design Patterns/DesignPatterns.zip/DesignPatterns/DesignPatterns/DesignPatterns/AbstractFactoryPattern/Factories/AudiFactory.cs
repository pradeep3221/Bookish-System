﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DesignPatterns.AbstractFactoryPattern.Classes;

namespace DesignPatterns.AbstractFactoryPattern.Factories
{
    public class AudiFactory: CarFactory
    {
        public override SportsCar CreateSportsCar()
        {
            return new AudiSportsCar();
        }

        public override FamilyCar CreateFamilyCar()
        {
            return new AudiFamilyCar();
        }
    }
}
